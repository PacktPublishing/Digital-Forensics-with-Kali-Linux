
                        Test 8 - JPEG Search Image #1
                                 June 2004

		                      http://dftt.sf.net
                                 Brian Carrier

---------------------------------------------------------------------------
This is a test image for testing digital forensic analysis tools.
Import it into the tool of your choice (it is a NTFS file system
image in a raw format) and search for the JPEG image files (if
automated techniques exist).  The file details can be found in
'index.html' file.

This image is released under the terms of the GNU General Public
License as published by the Free Software Foundation.  It is included
in the COPYING file.

Brian Carrier
carrier@cerias.purdue.edu
This work is not sponsored by Purdue University or CERIAS.
